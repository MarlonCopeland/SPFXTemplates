import { WebPartContext } from '@microsoft/sp-webpart-base';
import { IReqTeamProps } from "../webparts/ReqTeam/components/IReqTeamProps";
import { IReqTeamState } from "../webparts/ReqTeam/components/IReqTeamState";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/files";
import '@pnp/sp/site-users/web';
import { BaseFormService } from "./BaseFormService";
import { HrodsProps } from "./IBaseFormService";
export declare class RqtFormService extends BaseFormService {
    constructor(SPX: WebPartContext);
    validateHrodsUser(UserId: string, Ctx: IReqTeamProps): Promise<boolean>;
    validateHrodsUsr(UserId: string, Ctx: HrodsProps): Promise<boolean>;
    validateTeamName(Prefix: string, DCLvl: string, TName: string): Promise<string[]>;
    saveRqtData(Rqt_List: string, Data: IReqTeamState): Promise<boolean>;
}
//# sourceMappingURL=RqtFormService.d.ts.map