import { WebPartContext } from '@microsoft/sp-webpart-base';
import IRqsFormService from '../../../services/IRqsFormService';

export interface ISvstQuestionnaireProps {
  spctx: WebPartContext;
  formsvc: IRqsFormService;
  rqs_siteurl: string;
  rqs_list: string;
  hrods_splist: string;
  hrods_field: string;
  hrods_doclib: string;
  hrods_file: string;
  description: string;
  isDarkTheme: boolean;
  environmentMessage: string;
  hasTeamsContext: boolean;
  userDisplayName: string;
}
