import { WebPartContext } from '@microsoft/sp-webpart-base';
import IRqsFormService from '../../../services/IRqsFormService';
export interface IReqSpoSiteProps {
    SpContext: WebPartContext;
    FormService: IRqsFormService;
    SiteUrl: string;
    List: string;
    HrodsSpList: string;
    HrodsField: string;
    HrodsDocLib: string;
    HrodsFile: string;
    Description: string;
    IsDarkTheme: boolean;
    EnvironmentMessage: string;
    HasTeamsContext: boolean;
    UserDisplayName: string;
}
//# sourceMappingURL=IReqSpoSiteProps.d.ts.map