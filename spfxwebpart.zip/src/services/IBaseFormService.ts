/// Describe purpose of Interface and value purposes
export class HrodsProps {
    public hrods_root: string;
    public hrods_splist: string;
    public hrods_field: string;
    public hrods_doclib: string;
    public hrods_file: string;
}

export default interface IBaseFormService {
    // validate user against HRODS gold source
    validateHrodsUsr(UserId:string, Ctx:HrodsProps): Promise<boolean>;
}

