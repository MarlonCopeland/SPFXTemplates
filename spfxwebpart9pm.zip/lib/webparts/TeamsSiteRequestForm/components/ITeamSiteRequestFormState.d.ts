import { IPickerTerm } from "@pnp/spfx-controls-react/lib/TaxonomyPicker";
export interface ITeamSiteRequestFormState {
    Requestor: string;
    AsOwner: boolean;
    IsManager: boolean;
    Approver: any;
    IsPII: boolean;
    FIPS: string;
    Owners: any[];
    OwningOrg: IPickerTerm | null;
    DcLevel: string;
    TeamName: string;
    Privacy: string;
    Project: string;
    Capstone: string;
    Description: string;
    ErrorMessage: string;
    TeamNameError: string;
}
export declare const TeamSiteRequestFormStateDefault: ITeamSiteRequestFormState;
//# sourceMappingURL=ITeamSiteRequestFormState.d.ts.map