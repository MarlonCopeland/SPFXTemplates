export declare class HrodsProps {
    hrods_root: string;
    hrods_splist: string;
    hrods_field: string;
    hrods_doclib: string;
    hrods_file: string;
}
export default interface IBaseFormService {
    validateHrodsUsr(UserId: string, Ctx: HrodsProps): Promise<boolean>;
}
//# sourceMappingURL=IBaseFormService.d.ts.map