import { IPickerTerm } from "@pnp/spfx-controls-react/lib/TaxonomyPicker";
  
export interface ISvstQuestionnaireState {
    // Standard fields from IReqSpoSiteState
    Requestor: string;
    InheritPermissions: boolean;
    InheritNavigation: boolean;
    IsManager: boolean;
    IsPII: boolean;
    Manager: any[];
    SiteOwners: any[];
    PrimarySCA: any[];
    SecondarySCA: any[];
    SiteApprovers: any[];
    ParentURL: string;
    SiteTitle: string;
    SiteType: string;
    SiteTypeId: string;
    SiteDescription: string;
    OwningOrg: IPickerTerm | null;
    FIPS: string;
    TimeZone: string;

    // Additional validation/UI state
    ErrorMessage: string;
    ManagerValid: boolean;  // was rqs_Manager_ok
}

export const SvstQuestionnaireStateDefault: ISvstQuestionnaireState = {
    // Initialize with empty/default values
    Requestor: "",
    InheritPermissions: false,
    InheritNavigation: false,
    IsManager: false,
    IsPII: false,
    Manager: [],
    SiteOwners: [],
    PrimarySCA: [],
    SecondarySCA: [],
    SiteApprovers: [],
    ParentURL: "",
    SiteTitle: "",
    SiteType: "",
    SiteTypeId: "",
    SiteDescription: "",
    OwningOrg: null,
    FIPS: "",
    TimeZone: "",
    ErrorMessage: "",
    ManagerValid: false
};