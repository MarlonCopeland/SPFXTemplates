import { IReqTeamProps } from "../webparts/ReqTeam/components/IReqTeamProps";
import { IReqTeamState } from "../webparts/ReqTeam/components/IReqTeamState";

export default interface IRqtFormService {
    // validate user against HRODS gold source
    validateHrodsUser(UserId:string, Ctx:IReqTeamProps): Promise<boolean>;

    // validate team name
    validateTeamName(Prefix:string, DCLvl:string, TName:string): Promise<string[]>;

    // save Rqt form data to SPOList
    saveRqtData(Rqt_List:string, Data:IReqTeamState): Promise<boolean>;
}