export declare function isNonNull(str: string | null | undefined): boolean;
//# sourceMappingURL=Util.d.ts.map