import { IReqTeamProps } from "../webparts/ReqTeam/components/IReqTeamProps";
import { IReqTeamState } from "../webparts/ReqTeam/components/IReqTeamState";
export default interface IRqtFormService {
    validateHrodsUser(UserId: string, Ctx: IReqTeamProps): Promise<boolean>;
    validateTeamName(Prefix: string, DCLvl: string, TName: string): Promise<string[]>;
    saveRqtData(Rqt_List: string, Data: IReqTeamState): Promise<boolean>;
}
//# sourceMappingURL=IRqtFormService.d.ts.map