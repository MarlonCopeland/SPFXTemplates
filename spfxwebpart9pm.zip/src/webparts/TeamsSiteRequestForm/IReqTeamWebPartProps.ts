export interface ITeamSiteRequest {
  ReqTeam: string;
  ReqList: string;
  HrodsList: string;
  HrodsField: string;
  HrodsDoclib: string;
  HrodsFile: string;
}