import { IReqSpoSiteProps } from "../webparts/ReqSpoSite/components/IReqSpoSiteProps";
import { IReqSpoSiteState } from "../webparts/ReqSpoSite/components/IReqSpoSiteState";

export default interface IRqsFormService {
    // validate user against HRODS gold source
    validateHrodsUser(userId: string, context: IReqSpoSiteProps): Promise<boolean>;

    // save RQS form data to SPOList
    saveRQSData(listName: string, data: IReqSpoSiteState): Promise<boolean>;
}