export declare const SITETYPES: string[];
export declare const DCLVLS: string[];
export declare const PRIVACY: string[];
export declare const CAPSTONE: string[];
export declare const FIPSLVLS: string[];
export declare const TIMEZONES: string[];
//# sourceMappingURL=Constants.d.ts.map