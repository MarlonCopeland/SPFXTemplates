import { IPickerTerm } from "@pnp/spfx-controls-react/lib/TaxonomyPicker";
export interface IReqSpoSiteState {
    Requestor: string;
    InheritPermissions: boolean;
    InheritNavigation: boolean;
    IsManager: boolean;
    IsPII: boolean;
    Manager: any[];
    SiteOwners: any[];
    PrimarySCA: any[];
    SecondarySCA: any[];
    SiteApprovers: any[];
    ParentURL: string;
    SiteTitle: string;
    SiteType: string;
    SiteTypeId: string;
    SiteDescription: string;
    OwningOrg: IPickerTerm | null;
    FIPS: string;
    TimeZone: string;
    ErrorMessage: string;
}
export declare const ReqSpoSiteStateDefault: IReqSpoSiteState;
//# sourceMappingURL=IReqSpoSiteState.d.ts.map