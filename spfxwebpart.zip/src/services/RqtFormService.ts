import { sp } from "@pnp/sp";
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { IReqTeamProps } from "../webparts/ReqTeam/components/IReqTeamProps";
import { IReqTeamState } from "../webparts/ReqTeam/components/IReqTeamState";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/files";
import '@pnp/sp/site-users/web';
import * as util from '../common/Util';
import { BaseFormService } from "./BaseFormService";
import { HrodsProps } from "./IBaseFormService";


/// SVST form business rules d
export class RqtFormService extends BaseFormService {

  public constructor (SPX:WebPartContext) {
      super(SPX);
      sp.setup({spfxContext: SPX});
  }

  public async validateHrodsUser(UserId:string, Ctx:IReqTeamProps): Promise<boolean> {
    let bc:HrodsProps = new HrodsProps;
    bc.hrods_root =  Ctx.rqt_siteurl;
    bc.hrods_splist = Ctx.hrods_splist;
    bc.hrods_field = Ctx.hrods_field;
    bc.hrods_doclib = Ctx.hrods_doclib;
    bc.hrods_file = Ctx.hrods_file;  
    return this.validateHrodsUsr(UserId,bc);
  }
    
  public async validateHrodsUsr(UserId:string, Ctx:HrodsProps): Promise<boolean> {
    return super.validateHrodsUsr(UserId,Ctx);
  }

  // validate team name
  public async validateTeamName(Prefix:string, DCLvl:string, TName:string): Promise<string[]> {
    return ['first static error','second static error'];
  }

      
  // Persist form data to the SPO request queue
  public async saveRqtData(Rqt_List:string, Data:IReqTeamState) : Promise<boolean> {
    let saw = null;
    if (Data.rqt_Approver !== null){
      const sa = Data.rqt_Approver.map(a => a.id);
      saw = { results: sa };
    }
    let tow = null;
    if (Data.rqt_Owners !== null){
      const to = Data.rqt_Owners.map(a => a.id);
      tow = { results: to };
    }

    try {
      const r = await sp.web.lists.getByTitle(Rqt_List).items.add({
        IsManager: Data.rqt_IsManager,
        Title: Data.rqt_TeamName,
        PII: Data.rqt_PII,
        FIPS: Data.rqt_FIPS,
        ManagerId: Data.rqt_Owners[0].id,
        OwnersId: tow,
        Description: Data.rqt_Description,
        OwningOrg: { 
          __metadata: { type: "SP.Taxonomy.TaxonomyFieldValue" },
          Label: Data.rqt_OwningOrg.name,
          TermGuid: Data.rqt_OwningOrg.key,
          WssId: -1
        },
      });
      console.log('Item added successfully!');

    } catch (ex) {
      console.error('Error adding item: ', ex);
    }
    
    return true;
  }
}