import {  IPickerTerm } from "@pnp/spfx-controls-react/lib/TaxonomyPicker";
  
export interface ISvstQuestionnaireState
{

    // user input fields
    rqs_SiteTitle : string;
    rqs_Requestor : string;
    rqs_SiteType : string;      //termstore ???
    rqs_SiteDescription : string;   
    rqs_TimeZone : string;      //dropdown
    rqs_PII : boolean;
    rqs_FIPS : string;
    rqs_OwningOrg : IPickerTerm | null;
    rqs_Manager : any;          
    rqs_IsManager : boolean;
    rqs_Manager_ok : boolean;   //validation result for manager field
    rqs_SiteOwners : any;       // multivalued users
    rqs_PrimarySCA : any;
    rqs_SecondarySCA : any;
    rqs_SiteApprovers : any;    // multivalued users

    // generated fields on submit
    rqs_ParentURL : string;
    rqs_SiteTypeId : string;
    rqs_InheritPermissions : boolean; 
    rqs_InheritNavigation : boolean;

    errmsg : string;
}

export const SvstQuestionnaireStateDefault : ISvstQuestionnaireState = {
    rqs_SiteTitle : "",
    rqs_Requestor : "",
    rqs_SiteType : "",
    rqs_SiteDescription : "",   
    rqs_TimeZone : "",
    rqs_PII : false,
    rqs_FIPS : "",
    rqs_OwningOrg : null, 
    rqs_Manager : null,
    rqs_IsManager: false,
    rqs_Manager_ok : false,
    rqs_SiteOwners : null,
    rqs_PrimarySCA : null,
    rqs_SecondarySCA : null,
    rqs_SiteApprovers : null,
    rqs_ParentURL : "",
    rqs_SiteTypeId : "",
    rqs_InheritPermissions : false,
    rqs_InheritNavigation : false,
    errmsg : ""
};