import { WebPartContext } from '@microsoft/sp-webpart-base';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/files";
import '@pnp/sp/site-users/web';
import IBaseFormService, { HrodsProps } from "./IBaseFormService";
export declare class BaseFormService implements IBaseFormService {
    private _sp;
    constructor(SPX: WebPartContext);
    validateHrodsUsr(UserId: string, Ctx: HrodsProps): Promise<boolean>;
    private validateHrodsList;
}
//# sourceMappingURL=BaseFormService.d.ts.map