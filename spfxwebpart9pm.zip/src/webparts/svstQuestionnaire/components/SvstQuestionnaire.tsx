import * as React from 'react';
import styles from './SvstQuestionnaire.module.scss';
import { ISvstQuestionnaireProps } from './ISvstQuestionnaireProps';
import { ISvstQuestionnaireState, SvstQuestionnaireStateDefault } from './SvstQuestionnaireState';
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { TaxonomyPicker, IPickerTerms } from "@pnp/spfx-controls-react/lib/TaxonomyPicker";
import * as constants from '../../../common/Constants';

export default class ReqSpoSite extends React.Component<ISvstQuestionnaireProps, ISvstQuestionnaireState> {
  constructor(props: ISvstQuestionnaireProps) {
    super(props);
    this.state = SvstQuestionnaireStateDefault;
  }

  public componentDidMount(): void {
    if (this.state.Requestor == null) {
      this.setState({ Requestor: this.props.SpContext.pageContext.user.displayName });
    }
    if (this.state.ParentURL == null) {
      this.setState({ ParentURL: this.props.SpContext.pageContext.web.absoluteUrl });
    }
  }

  private handleSubmit = async (event: React.FormEvent): Promise<void> => {
    event.preventDefault();
    this.props.FormService.saveRQSData(this.props.List, this.state);
  }

  private chkSubmit(): boolean {
    return (this.state.SiteTitle !== null) && (this.state.ManagerValid === true);
  }

  public onOrgPickerChange = (terms: IPickerTerms): void => {
    console.log('onOrgPickerChange', terms);
    if (terms.length > 0) {
      this.setState(prevState => ({
        ...prevState,
        OwningOrg: terms[0]
      }), () => this.chkSubmit());
    } else {
      this.setState(prevState => ({
        ...prevState,
        OwningOrg: null
      }), () => this.chkSubmit());
    }
  }

  public onSCAPickerChange = (items: any[], targetField: string): void => {
    const fieldKey = targetField as keyof ISvstQuestionnaireState;
    this.setState(prevState => ({
      ...prevState,
      [fieldKey]: items.length > 0 ? items[0].id : ''
    }), () => this.chkSubmit());
  }

  private onManagerPickerChange = async (items: any[]): Promise<void> => {
    let mv = false;
    if (items.length > 0) {
      let msg = "";
      for (let i = items.length - 1; i >= 0; i--) {
        if (items[i].secondaryText !== null) {
          const v = await this.props.FormService.validateHrodsUser(items[i].secondaryText, this.props);
          mv = mv || v;
          msg += v ? "" : `<${items[i].text}> is not a HRODS member`;
        } else {
          console.log(`internal error: unable to extract email from userid <${items[i].loginName}>`);
        }
      }
      console.log(msg);
      this.setState(prevState => ({
        ...prevState,
        SiteOwners: items,
        Manager: items,
        ManagerValid: mv,
        ErrorMessage: msg
      }));
    } else {
      this.setState(prevState => ({
        ...prevState,
        Manager: [],
        ManagerValid: mv,
        ErrorMessage: "select a person"
      }));
    }
  }

  private onSelectChange = (e: React.ChangeEvent<HTMLSelectElement>): void => {
    const stateKey = e.target.id as keyof ISvstQuestionnaireState;
    if (stateKey in this.state) {
      const value = e.target.value;
      this.setState(prevState => ({
        ...prevState,
        [stateKey]: value
      }), () => this.chkSubmit());
    } else {
      console.log("error: unknown property", e.target.id);
    }
  }

  private onCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
    const stateKey = e.target.id as keyof ISvstQuestionnaireState;
    if (stateKey in this.state) {
      this.setState(prevState => ({
        ...prevState,
        [stateKey]: e.target.checked
      }), () => this.chkSubmit());
    } else {
      console.log("error: unknown property", e.target.id);
    }
  }

  public onTextChange = (evt: React.ChangeEvent<HTMLInputElement>): void => {
    const id = evt.target.id as keyof ISvstQuestionnaireState;
    this.setState(prevState => ({
      ...prevState,
      [id]: evt.target.value
    }), () => this.chkSubmit());
  }

  public onTAreaChange = (evt: React.ChangeEvent<HTMLTextAreaElement>): void => {
    const id = evt.target.id as keyof ISvstQuestionnaireState;
    this.setState(prevState => ({
      ...prevState,
      [id]: evt.target.value
    }), () => this.chkSubmit());
  }

  private getSitetypeOptions(stypes: string[]): JSX.Element[] {
    return stypes.map(v => <option key={v} value={v}>{v}</option>);
  }

  private getTimeZoneOptions(tzones: string[]): JSX.Element[] {
    return tzones.map(v => <option key={v} value={v}>{v}</option>);
  }

  public render(): React.ReactElement<ISvstQuestionnaireProps> {
    return (
      <div className={styles.ReqSpoSite}>
        <div className={styles.title}>New SharePointOnline Site Request</div>
        <form onSubmit={this.handleSubmit}>
          <div className={styles.info}>
            <div className={styles.name}>Site Title</div>
            <div className={styles.help}>
              The site title should be easily identified by those who will be using the site.
            </div>
          </div>
          <div className={styles.data}>
            <div className={styles.entry}>
              <input 
                aria-label="title" 
                type="text" 
                id="SiteTitle" 
                className={styles.itext}
                onChange={this.onTextChange} 
              />
            </div>
            <div className={styles.msg}>Enter site title.</div>
          </div>

          <div className={styles.info}>
            <div className={styles.name}>Default Time Zone</div>
            <div className={styles.help}>Select the default timezone of the site</div>
          </div>
          <div className={styles.data}>
            <div className={styles.entry}>
              <select 
                aria-label="timezone" 
                id="TimeZone" 
                className={styles.iselect}
                onChange={this.onSelectChange}
              >
                {this.getTimeZoneOptions(constants.TIMEZONES)}
              </select>
            </div>
            <div className={styles.msg}></div>
          </div>

          <div className={styles.info}>
            <div className={styles.name}>Site Requestor</div>
            <div className={styles.help}>
              Site requestors receive contribute access by default. If you are also the administrator, 
              please enter your name in either the Primary or Secondary Site Collection Administrator field.
            </div>
          </div>
          <div className={styles.data}>
            <div className={styles.entry}>
              <div>{this.state.Requestor}</div>
            </div>
            <div className={styles.msg}>current user</div>
          </div>

          <div className={styles.info}>
            <div className={styles.name}>Are you a manager?</div>
            <div className={styles.help}>
              Please check the box if you are a manager. If you are not a manager, 
              leave this box unchecked and enter your manager's name in the box below.
            </div>
          </div>
          <div className={styles.data}>
            <div className={styles.entry}>
              <input 
                aria-label="manager" 
                type="checkbox" 
                id="IsManager"
                onChange={this.onCheckboxChange}
              />
            </div>
            <div className={styles.msg}>Check this box if you are a manager</div>
          </div>

          <div className={styles.info}>
            <div className={styles.name}>Manager</div>
            <div className={styles.help}>
              If you are not a manager, please enter your manager's name in the box below. 
              They will be contacted for approval and will be accountable for the security and content of the site.
            </div>
          </div>
          <div className={styles.data} id="Manager">
            <div className={styles.entry}>
              <PeoplePicker
                context={this.props.SpContext}
                titleText="HRODS Manager Picker"
                personSelectionLimit={1}
                showtooltip={true}
                required={true}
                disabled={false}
                ensureUser={true}
                principalTypes={[PrincipalType.User]}
                onChange={this.onManagerPickerChange}
                errorMessage={this.state.ErrorMessage}
                resolveDelay={1000}
              />
            </div>
            <div className={styles.msg}>Enter at least 3 characters of the email address for suggestions</div>
          </div>

          <div className={styles.info}>
            <div className={styles.name}>PII or FTI</div>
            <div className={styles.help}>
              If your site will contain Personally Identifiable Information (PII) or Federal Tax Information (FTI), 
              please check this box.
            </div>
          </div>
          <div className={styles.data}>
            <div className={styles.entry}>
              <input 
                aria-label="PII" 
                type="checkbox" 
                id="IsPII"
                onChange={this.onCheckboxChange}
              />
            </div>
            <div className={styles.msg}>Check this box if site to contain PII or FTI</div>
          </div>

          <div className={styles.info}>
            <div className={styles.name}>FIPS Level</div>
            <div className={styles.help}>
              Information rated as 'High' FIPS security level is not permitted on SharePoint.  
              For a detailed description of FIPS security standards at SSA, please see the <a href="#" data-bind="click: showFipsTooltipModal" target="_blank" rel="noopener noreferrer">Security Compliance Policy</a>.
            </div>
          </div>
          <div className={styles.data}>
            <div className={styles.entry}>
              <select 
                aria-label="FIPS" 
                id="FIPS" 
                className={styles.iselect}
                onChange={this.onSelectChange}
              >
                {this.getSitetypeOptions(constants.FIPSLVLS)}
              </select>
            </div>
            <div className={styles.msg}>Specify site's FIPS level</div>
          </div>

          <div className={styles.info}>
            <div className={styles.name}>Site Types</div>
            <div className={styles.help}>descriptive text regarding site types</div>
          </div>
          <div className={styles.data}>
            <div className={styles.entry}>
              <select 
                aria-label="sitetype" 
                id="SiteType" 
                className={styles.iselect}
                onChange={this.onSelectChange}
              >
                {this.getSitetypeOptions(constants.SITETYPES)}
              </select>
            </div>
            <div className={styles.msg}>select a site type.</div>
          </div>

          <div className={styles.info}>
            <div className={styles.name}>Owning Organization</div>
            <div className={styles.help}>
              To select the Owning Organization of your new site, start typing the organization acronym 
              or select the organization by clicking the tags on the right. 
              Once you click the tags, you can expand SSA to drill down to your organization.
              Unable to find your Organization? Click <a href="#" aria-haspopup="true" tabIndex={0} aria-label="request organization" title="Request Organization">here</a> to 
              request that it be added. The request form will open in a separate tab within your current browser.
            </div>
          </div>
          <div className={styles.data}>
            <div className={styles.entry} id="OwningOrg">
              <TaxonomyPicker
                allowMultipleSelections={false} 
                termsetNameOrID="Organizational Hierarchy" 
                panelTitle="Select Organization"
                label=""
                context={this.props.SpContext} 
                onChange={this.onOrgPickerChange} 
                isTermSetSelectable={false}
              />
            </div>
            <div className={styles.msg}>additional data related information</div>
          </div>

          <div className={styles.info}>
            <div className={styles.name}>Primary SCA</div>
            <div className={styles.help}>
              The primary Site Collection Administrator (SCA) is responsible for the site's content and administration.
            </div>
          </div>
          <div className={styles.data} id="PrimarySCA">
            <div className={styles.entry}>
              <PeoplePicker
                context={this.props.SpContext}
                titleText="SCA Picker"
                personSelectionLimit={1}
                showtooltip={true}
                required={true}
                disabled={false}
                ensureUser={true}                  
                principalTypes={[PrincipalType.User]}
                onChange={(e) => this.onSCAPickerChange(e, 'PrimarySCA')}
                errorMessage={this.state.ErrorMessage}
                resolveDelay={1000}
              />
            </div>
            <div className={styles.msg}>Enter at least 3 characters of the email address for suggestions</div>
          </div>

          <div className={styles.info}>
            <div className={styles.name}>Secondary SCA</div>
            <div className={styles.help}>
              The secondary Site Collection Administrator (SCA) resumes all responsibilities of the primary SCA, 
              in case the primary SCA is not immediately available.
            </div>
          </div>
          <div className={styles.data} id="SecondarySCA">
            <div className={styles.entry}>
              <PeoplePicker
                context={this.props.SpContext}
                titleText="SCA Picker"
                personSelectionLimit={1}
                showtooltip={true}
                required={true}
                disabled={false}
                ensureUser={true}
                principalTypes={[PrincipalType.User]}
                onChange={(e) => this.onSCAPickerChange(e, 'SecondarySCA')}
                errorMessage={this.state.ErrorMessage}
                resolveDelay={1000}
              />
            </div>
            <div className={styles.msg}>Enter at least 3 characters of the email address for suggestions</div>
          </div>

          <div className={styles.info}>
            <div className={styles.name}>Site Description</div>
            <div className={styles.help}>Briefly describe the site's purpose and content</div>
          </div>
          <div className={styles.data}>
            <div className={styles.entry}>
              <textarea 
                aria-label="description" 
                id="SiteDescription" 
                rows={6} 
                className={styles.inote}
                onChange={this.onTAreaChange}
              />
            </div>
            <div className={styles.msg}>additional data related information</div>
          </div>

          <div className={styles.actionsDiv}>
            <div className={styles.actions}>
              <button type="submit" disabled={!this.chkSubmit()}>Submit</button>
              <button type="button">Cancel</button>
            </div>
          </div>
        </form>
      </div>
    );
  }
}