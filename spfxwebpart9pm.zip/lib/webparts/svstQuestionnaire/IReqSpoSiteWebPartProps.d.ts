export interface IReqSpoSiteWebPartProps {
    ReqSpoSite: string;
    ReqList: string;
    HrodsList: string;
    HrodsField: string;
    HrodsDoclib: string;
    HrodsFile: string;
    description: string;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
}
//# sourceMappingURL=IReqSpoSiteWebPartProps.d.ts.map