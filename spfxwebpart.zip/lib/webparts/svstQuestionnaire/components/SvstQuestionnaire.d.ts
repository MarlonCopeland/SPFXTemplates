import * as React from 'react';
import { ISvstQuestionnaireProps } from './ISvstQuestionnaireProps';
import { ISvstQuestionnaireState } from './SvstQuestionnaireState';
export default class ReqSpoSite extends React.Component<ISvstQuestionnaireProps, ISvstQuestionnaireState> {
    constructor(props: ISvstQuestionnaireProps);
    componentDidMount(): void;
    private handleSubmit;
    private chkSubmit;
    private onOrgPickerChange;
    private onSCAPickerChange;
    private onManagerPickerChange;
    private onSelectChange;
    private onCheckboxChange;
    private onTextChange;
    private onTAreaChange;
    private getSitetypeOptions;
    private getTimeZoneOptions;
    render(): React.ReactElement<ISvstQuestionnaireProps>;
}
//# sourceMappingURL=SvstQuestionnaire.d.ts.map