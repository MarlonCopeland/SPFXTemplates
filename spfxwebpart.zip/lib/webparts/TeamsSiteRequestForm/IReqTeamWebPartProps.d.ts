export interface IReqTeamWebPartProps {
    ReqTeam: string;
    ReqList: string;
    HrodsList: string;
    HrodsField: string;
    HrodsDoclib: string;
    HrodsFile: string;
}
//# sourceMappingURL=IReqTeamWebPartProps.d.ts.map