import { IPickerTerm } from "@pnp/spfx-controls-react/lib/TaxonomyPicker";
export interface ISvstQuestionnaireState {
    rqs_SiteTitle: string;
    rqs_Requestor: string;
    rqs_SiteType: string;
    rqs_SiteDescription: string;
    rqs_TimeZone: string;
    rqs_PII: boolean;
    rqs_FIPS: string;
    rqs_OwningOrg: IPickerTerm | null;
    rqs_Manager: any;
    rqs_IsManager: boolean;
    rqs_Manager_ok: boolean;
    rqs_SiteOwners: any;
    rqs_PrimarySCA: any;
    rqs_SecondarySCA: any;
    rqs_SiteApprovers: any;
    rqs_ParentURL: string;
    rqs_SiteTypeId: string;
    rqs_InheritPermissions: boolean;
    rqs_InheritNavigation: boolean;
    errmsg: string;
}
export declare const SvstQuestionnaireStateDefault: ISvstQuestionnaireState;
//# sourceMappingURL=SvstQuestionnaireState.d.ts.map