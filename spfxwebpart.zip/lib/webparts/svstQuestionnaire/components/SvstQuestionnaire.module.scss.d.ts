declare const styles: {
    ReqSpoSite: string;
    title: string;
    subTitle: string;
    description: string;
    button: string;
    label: string;
    info: string;
    name: string;
    help: string;
    data: string;
    entry: string;
    itext: string;
    iselect: string;
    inote: string;
    msg: string;
    actionsDiv: string;
    actions: string;
};
export default styles;
//# sourceMappingURL=SvstQuestionnaire.module.scss.d.ts.map