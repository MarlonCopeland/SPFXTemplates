export declare class HrodsProps {
    RootSite: string;
    SharePointList: string;
    FieldName: string;
    DocumentLibrary: string;
    FileName: string;
}
export default interface IBaseFormService {
    validateHrodsUsr(UserId: string, Ctx: HrodsProps): Promise<boolean>;
}
//# sourceMappingURL=IBaseFormService.d.ts.map