import { WebPartContext } from '@microsoft/sp-webpart-base';
import { ServiceKey } from '@microsoft/sp-core-library';
import { IReqSpoSiteProps } from "../webparts/ReqSpoSite/components/IReqSpoSiteProps";
import { IReqSpoSiteState } from "../webparts/ReqSpoSite/components/IReqSpoSiteState";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/files";
import '@pnp/sp/site-users/web';
import { BaseFormService } from "./BaseFormService";
import { HrodsProps } from "./IBaseFormService";
import IRqsFormService from "./IRqsFormService";
export declare class RqsFormService extends BaseFormService implements IRqsFormService {
    constructor(context: WebPartContext);
    validateHrodsUser(userId: string, context: IReqSpoSiteProps): Promise<boolean>;
    validateHrodsUsr(UserId: string, Ctx: HrodsProps): Promise<boolean>;
    saveRQSData(listName: string, data: IReqSpoSiteState): Promise<boolean>;
}
export declare const RqsFormServiceKey: ServiceKey<IRqsFormService>;
export default RqsFormService;
//# sourceMappingURL=RqsFormService.d.ts.map