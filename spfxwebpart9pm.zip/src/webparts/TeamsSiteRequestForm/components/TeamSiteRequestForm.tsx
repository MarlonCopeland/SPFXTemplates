import * as React from 'react';
import styles from './TeamSiteRequestForm.module.scss';
import { ITeamSiteRequestFormProps } from './ITeamSiteRequestFormProps';
import { ITeamSiteRequestFormState, TeamSiteRequestFormStateDefault } from './ITeamSiteRequestFormState';
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { TaxonomyPicker, IPickerTerms } from "@pnp/spfx-controls-react/lib/TaxonomyPicker";
import * as constants from '../../../common/Constants';
//import * as util from '../../../common/Util';


export default class ReqTeam extends React.Component<ITeamSiteRequestFormProps, ITeamSiteRequestFormState> 
{
  
  constructor(props: ITeamSiteRequestFormProps) {
    super(props);
    this.state = TeamSiteRequestFormStateDefault;
  }

  public componentDidMount(): void {
    if (this.state.Requestor == null){
      this.setState({Requestor: this.props.SpContext.pageContext.user.displayName});
    }
  }

  /// Process form submission
  private handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    this.props.FormService.saveRqtData(this.props.List, this.state as any);
  }

  // Submit enabled flag
  private chkSubmit() : boolean {
    let rstat:boolean = false;
    rstat = (this.state.TeamName !== null);

    return rstat;
  }

  private onOrgPickerChange = (terms : IPickerTerms) : void => {
    console.log('onOrgPickerChange : ${terms}');
   if(terms.length>0){
     this.setState({OwningOrg:terms[0]}, ()=>{this.chkSubmit;});
   } else {
     this.setState({OwningOrg:null}, ()=>{this.chkSubmit;});
   }
  }
 
  private onOwnerPickerChange = async (items: any[],fld:string) : Promise<void> => {
    let o: any = {};
    if (items.length > 0) {
      if (!items[0].secondaryText){
        console.log(`internal error: unable to extract email from userid <${items[0].loginName}>`);
      }
      o[fld]=items;
      this.setState(o, ()=>{this.chkSubmit;});
    }
    else {
      o[fld] = null;
      this.setState(o, ()=>{this.chkSubmit;});
    }   
  }

  private onApproverPickerChange = async (items: any[]): Promise<void> => {
    await this.onOwnerPickerChange(items, 'rqt_Approver');
  }

  private onSelectChange = (e: React.ChangeEvent<HTMLSelectElement>): void => {
    console.log("select changed", e.target.value);
    if (e.target.id in this.state) {
      let o: any = {};
      o[e.target.id] = e.target.value;
      this.setState(o, () => { this.chkSubmit(); });
    } else {
      console.log("error: unknown property ", e.target.id);
    }
  }

  private onCheckboxChange = (e : React.ChangeEvent<HTMLInputElement>) : void => {
    console.log("checkbox changed",e.target.value);
   if (e.target.id in this.state)
   {
     let o: any = {};
     o[e.target.id] = e.target.checked;
     this.setState( o, ()=>{this.chkSubmit;} );
   }
    else
    {
       console.log("error: unknown property ",e.target.id);
    }
  }

  private onTextChange(e : React.ChangeEvent<HTMLInputElement>) : void {
    console.log("text changed",e.target.value);
   if (e.target.id in this.state)
   {
     let o: any = {};
     o[e.target.id] = e.target.value;
     this.setState( o, ()=>{this.chkSubmit;} );
   }
    else
    {
       console.log("error: unknown property ",e.target.id);
    }
  }

  private onTeamNameChange(e : React.ChangeEvent<HTMLInputElement>) : void {
    console.log("text changed",e.target.value);
   if (e.target.id in this.state)
   {
     let o: any = {};
     o[e.target.id] = e.target.value;
     const em = this.props.FormService.validateTeamName('#TT',this.state.DcLevel,e.target.value);
     o['TeamNameError'] = em;
     this.setState( o, ()=>{this.chkSubmit();} );
   }
    else
    {
       console.log("error: unknown property ",e.target.id);
    }
  }


  private onTAreaChange(e : React.ChangeEvent<HTMLTextAreaElement>) : void {
    console.log("text changed",e.target.value);
   if (e.target.id in this.state)
   {
     let o: any = {};
     o[e.target.id] = e.target.value;
     this.setState( o, ()=>{this.chkSubmit;} );
   }
    else
    {
       console.log("error: unknown property ",e.target.id);
    }
  }

  private getOptions(stypes:Array<string>) : JSX.Element {
    let opts:any = [];
    stypes.map((v)=>{opts.push(<option value={v}>{v}</option>);});
    return opts;
  }

  public render(): React.ReactElement<ITeamSiteRequestFormProps> {

  const err_tname = this.state.TeamNameError !== null ? "some error messages to display" : "no messages";

    return (
      <div className={styles['ReqTeam']}>
        <div className={ styles.title }>New M365 Team Request</div>
        <form onSubmit={this.handleSubmit}>

            <div className={styles['info']}>
              <div className={styles['name']}>Team Requestor</div>
              <div className={styles['help']}>Team requestors receive contribute access by default.</div>
            </div>
            <div className={styles['data']}>
              <div className={styles['entry']}>
                <div>{this.state.Requestor}</div>
              </div>
              <div className={styles['msg']}>current user</div>
            </div>

            <div className={styles['info']}>
              <div className={styles['name']}>Team Owner</div>
              <div className={styles['help']}>
                As the requestor, do you wish to be added as a Team owner (with full contribute permissions)
              </div>
            </div>
            <div className={styles['data']}>
              <div className={styles['entry']}>
                <input aria-label='asowner' type="checkbox" id="rqt_AsOwner" onChange={(e:React.ChangeEvent<HTMLInputElement>) => {this.onCheckboxChange(e);}}></input>
              </div>
              <div className={styles['msg']}>Check this box if you wish to be added a Team owner</div>
            </div>

            <div className={styles['info']}>
              <div className={styles['name']}>Are you a manager?</div>
              <div className={styles['help']}>
                Manager help text here.
              </div>
            </div>
            <div className={styles['data']}>
              <div className={styles['entry']}>
                <input aria-label='manager' type="checkbox" id="rqt_IsManager" onChange={(e:React.ChangeEvent<HTMLInputElement>) => {this.onCheckboxChange(e);}}></input>
              </div>
              <div className={styles['msg']}>Check this box if are a manager</div>
            </div>

            <div className={styles['info']}>
              <div className={styles['name']}>Approver</div>
              <div className={styles['help']}>
                approving manager or supervisor help text here. single approver.
              </div>
            </div>
            <div className={styles['data']} id="rqt_approver">
              <div className={styles['entry']}>
                <PeoplePicker
                  context={this.props.SpContext}
                  titleText="Approver Picker"
                  personSelectionLimit={1}
                  showtooltip={true}
                  required={true}
                  disabled={false}
                  ensureUser={true}                  
                  principalTypes={[PrincipalType.User]}
                  onChange={this.onApproverPickerChange}
                  errorMessage={this.state.ErrorMessage}
                  resolveDelay={1000} />
              </div>
              <div className={styles['msg']}>Enter at least 3 characters of the approver's email address for a list of suggestions</div>
            </div>

            <div className={styles['info']}>
              <div className={styles['name']}>PII or FTI</div>
              <div className={styles['help']}>
              If your site will contain Personally Identifiable Information (PII) or Federal Tax Information (FTI), please check this box.
              </div>
            </div>
            <div className={styles['data']}>
              <div className={styles['entry']}>
                <input aria-label='PII' type="checkbox" id="rqt_PII" onChange={(e:React.ChangeEvent<HTMLInputElement>) => {this.onCheckboxChange(e);}}></input>
              </div>
              <div className={styles['msg']}>Check this box if site to contain PII or FTI</div>
            </div>

            <div className={styles['info']}>
              <div className={styles['name']}>FIPS Level</div>
              <div className={styles['help']}>
              Information rated as ‘High’ FIPS security level is not permitted on SharePoint.  For a detailed description of FIPS security standards at SSA, please see the <a href="#" data-bind="click: showFipsTooltipModal" target="_blank">Security Compliance Policy</a>.
              </div>
            </div>
            <div className={styles['data']}>
              <div className={styles['entry']}>
                <select aria-label='FIPS' multiple={false} id="rqt_FIPS" className={styles['iselect']} onChange={(e:React.ChangeEvent<HTMLSelectElement>) => {this.onSelectChange(e);}}>
                  {this.getOptions(constants.FIPSLVLS)}
                </select>
              </div>
              <div className={styles['msg']}>Specify site's FIPS level</div>
            </div>

            <div className={styles['info']}>
              <div className={styles['name']}>Team Owners</div>
              <div className={styles['help']}>
                Team owners and/or administrator help text message here. Multivalued user field. Max 3 people
              </div>
            </div>
            <div className={styles['data']} id="rqt_Owners">
              <div className={styles['entry']}>
                <PeoplePicker
                  context={this.props.SpContext}
                  titleText="Owner Picker"
                  personSelectionLimit={3}
                  showtooltip={true}
                  required={true}
                  disabled={false}
                  ensureUser={true}                  
                  principalTypes={[PrincipalType.User]}
                  onChange={(e)=>this.onOwnerPickerChange(e,'rqt_Owners')}
                  errorMessage={this.state.ErrorMessage}
                  resolveDelay={1000} />
              </div>
              <div className={styles['msg']}>Enter at least 3 characters of the manager's email address for a list of suggestions</div>
            </div>

            <div className={styles['info']}>
              <div className={styles['name']}>Owning Organization</div>
              <div className={styles['help']}>
                Requestor org structure help text here.
              </div>
            </div>
            <div className={styles['data']}>
              <div className={styles['entry']} id='rqt_OwningOrg'>
                <TaxonomyPicker
                  allowMultipleSelections={false} 
                  termsetNameOrID="Organizational Hierarchy" 
                  panelTitle="Select Organization"
                  label=""
                  context={this.props.SpContext} 
                  onChange={this.onOrgPickerChange} 
                  isTermSetSelectable={false} />
              </div>
              <div className={styles['msg']}>additional data related information</div>
            </div>

            <div className={styles['info']}>
              <div className={styles['name']}>DC Level</div>
              <div className={styles['help']}>descriptive text regarding DC levels</div>
            </div>
            <div className={styles['data']}>
              <div className={styles['entry']}>
                <select aria-label='DC level' multiple={false} id="rqt_DcLvl" className={styles['iselect']} onChange={(e:React.ChangeEvent<HTMLSelectElement>) => {this.onSelectChange(e);}}>
                  {this.getOptions(constants.DCLVLS)}
                </select>
              </div>
              <div className={styles['msg']}>select a DC</div>
            </div>

            <div className={styles['info']}>
              <div className={styles['name']}>Team name</div>
              <div className={styles['help']}>descriptive text regarding Team Name</div>
            </div>
            <div className={styles['data']}>
              <div className={styles['entry']}>
                <input className={styles['itext']} aria-label='team name' type="text" id="rqt_TeamName" onChange={(e:React.ChangeEvent<HTMLInputElement>) => {this.onTeamNameChange(e);}}></input>               
              </div>
              <div className={styles['msg']}>{err_tname}</div>
            </div>

            <div className={styles['info']}>
              <div className={styles['name']}>Project</div>
              <div className={styles['help']}>descriptive text regarding Project label</div>
            </div>
            <div className={styles['data']}>
              <div className={styles['entry']}>
                <input className={styles['itext']} aria-label='project' type="text" id="rqt_Project" onChange={(e:React.ChangeEvent<HTMLInputElement>) => {this.onTextChange(e);}}></input>               
              </div>
              <div className={styles['msg']}>project name validation messages</div>
            </div>

            <div className={styles['info']}>
              <div className={styles['name']}>Privacy</div>
              <div className={styles['help']}>descriptive text regarding Privacy</div>
            </div>
            <div className={styles['data']}>
              <div className={styles['entry']}>
                <select aria-label='privacy' multiple={false} id="rqt_Privacy" className={styles['iselect']} onChange={(e:React.ChangeEvent<HTMLSelectElement>) => {this.onSelectChange(e);}}>
                  {this.getOptions(constants.PRIVACY)}
                </select>
              </div>
              <div className={styles['msg']}></div>
            </div>

            <div className={styles['info']}>
              <div className={styles['name']}>Capstone</div>
              <div className={styles['help']}>descriptive text regarding Capstone specifications</div>
            </div>
            <div className={styles['data']}>
              <div className={styles['entry']}>
                <select aria-label='sitetype' multiple={false} id="rqt_SiteType" className={styles['iselect']} onChange={(e:React.ChangeEvent<HTMLSelectElement>) => {this.onSelectChange(e);}}>
                  {this.getOptions(constants.CAPSTONE)}
                </select>
              </div>
              <div className={styles['msg']}>select a DC</div>
            </div>

            <div className={styles['info']}>
              <div className={styles['name']}>Team Description</div>
              <div className={styles['help']}>Briefly describe the M365 Team's purpose and content</div>
            </div>
            <div className={styles['data']}>
              <div className={styles['entry']}>
                <textarea className={styles['inote']} aria-label='description' id="rqt_Description" rows={6} onChange={(e:React.ChangeEvent<HTMLTextAreaElement>) => {this.onTAreaChange(e);}}></textarea>
              </div>
              <div className={styles['msg']}>additional data related information</div>
            </div>

            <div className={styles['actionsDiv']}>
              <div className={styles['actions']}>
                <button type="submit" disabled={!this.chkSubmit()}>Submit</button>
                <button >Cancel</button>
              </div>
            </div>
        </form>
      </div>
    );

  }
}
