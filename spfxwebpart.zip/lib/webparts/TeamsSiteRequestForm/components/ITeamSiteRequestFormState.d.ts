import { IPickerTerm } from "@pnp/spfx-controls-react/lib/TaxonomyPicker";
export interface IReqTeamState {
    rqt_Requestor: string;
    rqt_AsOwner: boolean;
    rqt_IsManager: boolean;
    rqt_Approver: any;
    rqt_PII: boolean;
    rqt_FIPS: string;
    rqt_Owners: any;
    rqt_OwningOrg: IPickerTerm | null;
    rqt_DcLvl: string;
    rqt_TeamName: string;
    rqt_Privacy: string;
    rqt_Project: string;
    rqt_Capstone: string;
    rqt_Description: string;
    errmsg: string;
    err_tname: string;
}
export declare const ReqTeamStateDefault: IReqTeamState;
//# sourceMappingURL=ITeamSiteRequestFormState.d.ts.map