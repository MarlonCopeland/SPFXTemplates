export interface IReqSpoSiteWebPartProps {
    ReqSpoSite: string;
    ReqList: string;
    HrodsList: string;
    HrodsField: string;
    HrodsDoclib: string;
    HrodsFile: string;
}
//# sourceMappingURL=IReqSpoSiteWebPartProps.d.ts.map