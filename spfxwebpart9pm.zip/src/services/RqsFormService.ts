import { WebPartContext } from '@microsoft/sp-webpart-base';
import { ServiceKey } from '@microsoft/sp-core-library';
import { IReqSpoSiteProps } from "../webparts/ReqSpoSite/components/IReqSpoSiteProps";
import { IReqSpoSiteState } from "../webparts/ReqSpoSite/components/IReqSpoSiteState";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/files";
import '@pnp/sp/site-users/web';
import { BaseFormService } from "./BaseFormService";
import { HrodsProps } from "./IBaseFormService";
import IRqsFormService  from "./IRqsFormService";


/// SVST form business rules for new site requests
export class RqsFormService extends BaseFormService implements IRqsFormService {

     public constructor(context: WebPartContext) {
        super(context);
    }

    public async validateHrodsUser(userId: string, context: IReqSpoSiteProps): Promise<boolean> {
      const hrods = new HrodsProps();
      hrods.RootSite = context.SiteUrl;
      hrods.SharePointList = context.HrodsSpList;
      hrods.FieldName = context.HrodsField;
      hrods.DocumentLibrary = context.HrodsDocLib;
      hrods.FileName = context.HrodsFile;
      return this.validateHrodsUsr(userId, hrods);
    }

    public async validateHrodsUsr(UserId:string, Ctx:HrodsProps): Promise<boolean> {
      return super.validateHrodsUsr(UserId,Ctx);
    }

    // Persist form data to the SPO request queue
    public async saveRQSData(listName: string, data: IReqSpoSiteState): Promise<boolean> {
        let siteApprovers = null;
        if (data.SiteApprovers?.length > 0) {
          const approverIds = data.SiteApprovers.map((approver: { id: string }) => approver.id);
          siteApprovers = { results: approverIds };
        }
        
        let siteOwners = null;
        if (data.SiteOwners?.length > 0) {
          const ownerIds = data.SiteOwners.map((owner: { id: string }) => owner.id);
          siteOwners = { results: ownerIds };
        }
    
        try {
          await this._sp.web.lists.getByTitle(listName).items.add({
            Title: data.SiteTitle,
            InheritPermissions: data.InheritPermissions,
            InheritNavigation: data.InheritNavigation,
            PII: data.IsPII,
            IsManager: data.IsManager,
            ManagerId: data.Manager[0].id,
            SiteOwnersId: siteOwners,
            PrimarySCAId: data.PrimarySCA[0].id,
            SecondarySCAId: data.SecondarySCA[0].id,
            SiteApproversId: siteApprovers,
            ParentURL: { 
              Url: data.ParentURL,
              Description: "Parent URL" 
            },
            SiteType: data.SiteType,
            SiteTypeId: data.SiteTypeId,
            SiteDescription: data.SiteDescription,
            OwningOrg: { 
              __metadata: { type: "SP.Taxonomy.TaxonomyFieldValue" },
              Label: data.OwningOrg ? data.OwningOrg.name : '',
              TermGuid: data.OwningOrg ? data.OwningOrg.key : '',
              WssId: -1
            },
            FIPS: data.FIPS,
            TimeZone: data.TimeZone
          });
          console.log('Item added successfully!');
    
        } catch (ex) {
          console.error('Error adding item: ', ex);
        }
        
        return true;
    }
}

// ServiceKey for SPFx ServiceScope registration
export const RqsFormServiceKey: ServiceKey<IRqsFormService> = ServiceKey.create<IRqsFormService>('svst:RqsFormService', RqsFormService as any);

export default RqsFormService;