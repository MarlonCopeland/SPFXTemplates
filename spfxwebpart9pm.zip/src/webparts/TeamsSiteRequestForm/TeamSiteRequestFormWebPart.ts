import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  type IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';

import * as strings from 'SvstQuestionnaireWebPartStrings';
import SvstQuestionnaire from './components/TeamSiteRequestForm';
import { ITeamSiteRequestFormProps } from './components/ITeamSiteRequestFormProps';
import RqtFormService, { RqtFormServiceKey } from '../../services/RqtFormService';

export interface ITeamSiteRequestFormWebPartProps {
  SiteUrl: string;
  List: string;
  HrodsDocLib: string;
  HrodsFile: string;
  HrodsSpList: string;
  HrodsField: string;
  Description: string;
}

export default class TeamSiteRequestFormWebPart extends BaseClientSideWebPart<ITeamSiteRequestFormWebPartProps> {

  private _isDarkTheme: boolean = false;
  private _environmentMessage: string = '';

  public render(): void {
    const element: React.ReactElement<ITeamSiteRequestFormProps> = React.createElement(
      SvstQuestionnaire,
      {
        SpContext: this.context as any,
  FormService: this.context.serviceScope.consume(RqtFormServiceKey),
        SiteUrl: this.properties.SiteUrl,
        List: this.properties.List,
        HrodsDocLib: this.properties.HrodsDocLib,
        HrodsFile: this.properties.HrodsFile,
        HrodsSpList: this.properties.HrodsSpList,
        HrodsField: this.properties.HrodsField,
        Description: this.properties.Description,
        IsDarkTheme: this._isDarkTheme,
        EnvironmentMessage: this._environmentMessage,
        HasTeamsContext: !!this.context.sdks.microsoftTeams,
        UserDisplayName: this.context.pageContext.user.displayName
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onInit(): Promise<void> {
    // Extend context with absoluteUrl for PeoplePicker
    (this.context as any).absoluteUrl = this.context.pageContext.web.absoluteUrl;
  // Provide the RqtFormService instance into the current service scope
  this.context.serviceScope.provide(RqtFormServiceKey, new RqtFormService(this.context));
    
    return this._getEnvironmentMessage().then(message => {
      this._environmentMessage = message;
    });
  }



  private _getEnvironmentMessage(): Promise<string> {
    if (!!this.context.sdks.microsoftTeams) { // running in Teams, office.com or Outlook
      return this.context.sdks.microsoftTeams.teamsJs.app.getContext()
        .then(context => {
          let environmentMessage: string = '';
          switch (context.app.host.name) {
            case 'Office': // running in Office
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentOffice : strings.AppOfficeEnvironment;
              break;
            case 'Outlook': // running in Outlook
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentOutlook : strings.AppOutlookEnvironment;
              break;
            case 'Teams': // running in Teams
            case 'TeamsModern':
              environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentTeams : strings.AppTeamsTabEnvironment;
              break;
            default:
              environmentMessage = strings.UnknownEnvironment;
          }

          return environmentMessage;
        });
    }

    return Promise.resolve(this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentSharePoint : strings.AppSharePointEnvironment);
  }

  protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void {
    if (!currentTheme) {
      return;
    }

    this._isDarkTheme = !!currentTheme.isInverted;
    const {
      semanticColors
    } = currentTheme;

    if (semanticColors) {
      this.domElement.style.setProperty('--bodyText', semanticColors.bodyText || null);
      this.domElement.style.setProperty('--link', semanticColors.link || null);
      this.domElement.style.setProperty('--linkHovered', semanticColors.linkHovered || null);
    }

  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
