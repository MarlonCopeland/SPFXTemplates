import { ISvstQuestionnaireProps } from "../webparts/svstQuestionnaire/components/ISvstQuestionnaireProps";
import { ISvstQuestionnaireState } from "../webparts/svstQuestionnaire/components/SvstQuestionnaireState";
//import { HrodsProps } from "./IBaseFormService";

export default interface IRqsFormService {
    // validate user against HRODS gold source
    validateHrodsUser(UserId:string, Ctx:ISvstQuestionnaireProps): Promise<boolean>;

    // save RQS form data to SPOList
    saveRQSData(Rqs_List:string, Data:ISvstQuestionnaireState): Promise<boolean>;
}