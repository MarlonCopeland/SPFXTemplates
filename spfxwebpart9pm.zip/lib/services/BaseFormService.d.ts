import { SPFI } from "@pnp/sp";
import { WebPartContext } from '@microsoft/sp-webpart-base';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/files";
import '@pnp/sp/site-users/web';
import IBaseFormService, { HrodsProps } from "./IBaseFormService";
export declare class BaseFormService implements IBaseFormService {
    protected _sp: SPFI;
    constructor(context: WebPartContext);
    validateHrodsUsr(UserId: string, Ctx: HrodsProps): Promise<boolean>;
    private validateHrodsList;
}
//# sourceMappingURL=BaseFormService.d.ts.map