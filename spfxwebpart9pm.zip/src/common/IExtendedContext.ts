import { WebPartContext } from '@microsoft/sp-webpart-base';

// Extend WebPartContext to satisfy PeoplePicker requirements
export interface IExtendedContext extends WebPartContext {
    // Add required properties that IPeoplePickerContext expects
    absoluteUrl: string;
}