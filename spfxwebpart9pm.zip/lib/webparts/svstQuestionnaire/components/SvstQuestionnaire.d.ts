import * as React from 'react';
import { ISvstQuestionnaireProps } from './ISvstQuestionnaireProps';
import { ISvstQuestionnaireState } from './SvstQuestionnaireState';
import { IPickerTerms } from "@pnp/spfx-controls-react/lib/TaxonomyPicker";
export default class ReqSpoSite extends React.Component<ISvstQuestionnaireProps, ISvstQuestionnaireState> {
    constructor(props: ISvstQuestionnaireProps);
    componentDidMount(): void;
    private handleSubmit;
    private chkSubmit;
    onOrgPickerChange: (terms: IPickerTerms) => void;
    onSCAPickerChange: (items: any[], targetField: string) => void;
    private onManagerPickerChange;
    private onSelectChange;
    private onCheckboxChange;
    onTextChange: (evt: React.ChangeEvent<HTMLInputElement>) => void;
    onTAreaChange: (evt: React.ChangeEvent<HTMLTextAreaElement>) => void;
    private getSitetypeOptions;
    private getTimeZoneOptions;
    render(): React.ReactElement<ISvstQuestionnaireProps>;
}
//# sourceMappingURL=SvstQuestionnaire.d.ts.map