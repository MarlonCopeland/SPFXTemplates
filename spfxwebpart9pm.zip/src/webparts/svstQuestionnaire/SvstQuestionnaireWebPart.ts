import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration, PropertyPaneTextField } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import "@pnp/sp/webs";
import * as strings from 'SvstQuestionnaireWebPartStrings';
import ReqSpoSite from './components/SvstQuestionnaire';
import { ISvstQuestionnaireProps  } from './components/ISvstQuestionnaireProps';
import { IReqSpoSiteWebPartProps } from './IReqSpoSiteWebPartProps';
import { RqsFormService, RqsFormServiceKey } from '../../services/RqsFormService';

export default class ReqSpoSiteWebPart extends BaseClientSideWebPart<IReqSpoSiteWebPartProps> {
  // private _formsvc:RqsFormService;
  private _isDarkTheme: boolean = false;
  private _environmentMessage: string = '';

  protected onInit(): Promise<void> {
    // Extend context with absoluteUrl for PeoplePicker
    (this.context as any).absoluteUrl = this.context.pageContext.web.absoluteUrl;
    // Provide the RqsFormService instance into the current service scope
    this.context.serviceScope.provide(RqsFormServiceKey, new RqsFormService(this.context));
    return Promise.resolve();
  }

  public render(): void {
    const element: React.ReactElement<ISvstQuestionnaireProps> = React.createElement(
      ReqSpoSite,
      {
        SpContext: this.context as any,
        FormService: this.context.serviceScope.consume(RqsFormServiceKey),
        SiteUrl: this.properties.ReqSpoSite,
        List: this.properties.ReqList,
        HrodsSpList: this.properties.HrodsList,
        HrodsField: this.properties.HrodsField,
        HrodsDocLib: this.properties.HrodsDoclib,
        HrodsFile: this.properties.HrodsFile,
        Description: this.properties.description,
        IsDarkTheme: this._isDarkTheme,
        EnvironmentMessage: this._environmentMessage,
        HasTeamsContext: !!this.context.sdks.microsoftTeams,
        UserDisplayName: this.context.pageContext.user.displayName
      }
    );

    ReactDom.render(element, this.domElement);
    console.log("render method complete");
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('ReqSpoSite', {
                  label: strings.ReqSpoSite
                }),
                PropertyPaneTextField('ReqList', {
                  label: strings.ReqList
                }),
                PropertyPaneTextField('HrodsList', {
                  label: strings.HrodsList
                }),
                PropertyPaneTextField('HrodsField', {
                  label: strings.HrodsField
                }),
                PropertyPaneTextField('HrodsDoclib', {
                  label: strings.HrodsDoclib
                }),
                PropertyPaneTextField('HrodsFile', {
                  label: strings.HrodsFile
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
