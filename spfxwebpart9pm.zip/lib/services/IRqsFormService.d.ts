import { IReqSpoSiteProps } from "../webparts/ReqSpoSite/components/IReqSpoSiteProps";
import { IReqSpoSiteState } from "../webparts/ReqSpoSite/components/IReqSpoSiteState";
export default interface IRqsFormService {
    validateHrodsUser(userId: string, context: IReqSpoSiteProps): Promise<boolean>;
    saveRQSData(listName: string, data: IReqSpoSiteState): Promise<boolean>;
}
//# sourceMappingURL=IRqsFormService.d.ts.map