import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration, PropertyPaneTextField } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { sp } from "@pnp/sp";
import "@pnp/sp/webs";
import * as strings from 'SvstQuestionnaireWebPartStrings';
import ReqSpoSite from './components/SvstQuestionnaire';
import { ISvstQuestionnaireProps  } from './components/ISvstQuestionnaireProps';
import { IReqSpoSiteWebPartProps } from './IReqSpoSiteWebPartProps';
import IRqsFormService from '../../services/IRqsFormService';
import { RqsFormService } from '../../services/RqsFormService';

export default class ReqSpoSiteWebPart extends BaseClientSideWebPart<IReqSpoSiteWebPartProps> {

  private _formsvc:IRqsFormService;

  public onInit(): Promise<void> {
    return super.onInit().then(_ => {
      sp.setup({
        spfxContext: this.context
      });
      console.log("obtained client context");
      this._formsvc = new RqsFormService(this.context);
    });
  }

  public render(): void {
    const element: React.ReactElement<ISvstQuestionnaireProps> = React.createElement(
      ReqSpoSite,
      {
        spctx: this.context,
        formsvc: this._formsvc,
        rqs_siteurl: this.properties.ReqSpoSite,
        rqs_list: this.properties.ReqList,
        hrods_doclib: this.properties.HrodsDoclib,
        hrods_file: this.properties.HrodsFile,
        hrods_splist: this.properties.HrodsList,
        hrods_field: this.properties.HrodsField,
        description: this.properties.description,
        isDarkTheme: this._isDarkTheme,
        environmentMessage: this._environmentMessage,
        hasTeamsContext: !!this.context.sdks.microsoftTeams,
        userDisplayName: this.context.pageContext.user.displayName
      },
    );

    ReactDom.render(element, this.domElement);
    console.log("render method complete");
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('ReqSpoSite', {
                  label: strings.ReqSpoSite
                }),
                PropertyPaneTextField('ReqList', {
                  label: strings.ReqList
                }),
                PropertyPaneTextField('HrodsList', {
                  label: strings.HrodsList
                }),
                PropertyPaneTextField('HrodsField', {
                  label: strings.HrodsField
                }),
                PropertyPaneTextField('HrodsDoclib', {
                  label: strings.HrodsDoclib
                }),
                PropertyPaneTextField('HrodsFile', {
                  label: strings.HrodsFile
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
