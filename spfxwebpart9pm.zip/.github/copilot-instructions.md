## Quick purpose

This repository is a SharePoint Framework (SPFx) web part solution (v1.21.1). This file contains focused, actionable notes an AI coding agent needs to be immediately productive: architecture, build/debug commands, important conventions, and examples taken from the codebase.

## Quick start (commands for Windows PowerShell)

Run these from the repository root:

```powershell
npm install
npm run build    # runs `gulp bundle`
gulp serve       # launch local SPFx workbench for debugging
gulp test        # run project tests (if configured)
```

Note: package.json requires Node >=22.14.0 and <23.0.0. TypeScript output goes to `lib/` (see `tsconfig.json`).

## Big-picture architecture

- Top-level web parts live under `src/webparts/` (two examples: `svstQuestionnaire` and `TeamsSiteRequestForm`). Web parts host React components and pass the SPFx `WebPartContext` into service classes.
- App logic / business rules live in `src/services/`. Notable services:
  - `BaseFormService` — common SP/PnP helpers (has an SPFI field `_sp` declared but not fully initialized in base constructor).
  - `RqsFormService` & `RqtFormService` — extend `BaseFormService`, call `sp.setup({ spfxContext: SPX })` in their constructors and implement persistence methods (`saveRQSData`, `saveRqtData`). See `src/services/RqsFormService.ts` and `src/services/RqtFormService.ts`.
- Shared constants & small helpers live in `src/common/` (e.g., `Constants.ts` and `Util.ts` — contains `isNonNull`). These constants are used by forms (TIMEZONES, SITETYPES, etc.).
- Models / typed contracts live under `src/model/` and compiled `.js/.d.ts` versions exist in `lib/` and top-level `model/` for distribution.
- Packaging: built bundle files are produced under `release/` and a SharePoint package exists under `sharepoint/solution/svst-questionnaire.sppkg`.

## Important patterns & conventions (do not improvise without checking examples)

- SPFx + PnP usage: use `@pnp/sp`. Subclasses call `sp.setup({ spfxContext: SPX })` (see `RqsFormService` / `RqtFormService`). Some code hints at migrating to `spfi().using(SPFx(this.context))` (commented in `BaseFormService`). If you add or modify PnP usage, follow the existing pattern in the `services` constructors.
- Web part -> Service flow: web part passes `WebPartContext` into service constructor; service performs list/file operations. Example: `RqsFormService.saveRQSData` maps form state fields to SharePoint list item shape and calls `sp.web.lists.getByTitle(...).items.add({...})`.
- Taxonomy & complex field shapes: when writing to taxonomy fields, follow current pattern used in `saveRQSData` / `saveRqtData`: include `__metadata: { type: 'SP.Taxonomy.TaxonomyFieldValue' }`, `Label`, `TermGuid`, and `WssId: -1`.
- People/lookup fields mapping: follow `OwnersId: { results: [...] }` and single-person fields like `ManagerId: Data.rqs_Manager[0].id`.

## Data flow and key files to inspect for changes

- To modify how form data is persisted: edit `src/services/RqsFormService.ts` or `src/services/RqtFormService.ts`.
- To change form constants/options (site types, timezones): edit `src/common/Constants.ts`.
- To add utility helpers used by services: edit `src/common/Util.ts` and keep exports small and well-typed.

## Build/test/debug specifics

- Use `gulp serve` for local debugging in the SPFx workbench. The README mentions minimal steps (npm install; gulp serve).
- To create production assets use `npm run build` (alias for `gulp bundle`). The repo keeps build outputs in `lib/` and `release/`.
- Linting / TypeScript: project uses `@microsoft/rush-stack-compiler-5.3` and `@microsoft/eslint-config-spfx`. TypeScript target is ES5 (see `tsconfig.json`).

## Fragile / surprising bits discovered

- `BaseFormService` declares `_sp: SPFI` and a constructor that currently does not initialize it. Subclasses (Rqs/Rqt) call `sp.setup(...)` from `@pnp/sp`. If you need SPFI-based code, either initialize `_sp` in the base constructor (use `spfi().using(SPFx(ctx))`) or keep using the global `sp` setup pattern used elsewhere.
- HRODS validation: there are two approaches in code (file-based parsing vs. list-based). The file-based implementation is commented out. Current active logic favors list-based lookups (see `validateHrodsList`). If changing HRODS behavior, check `IBaseFormService` and callers in web parts.

## Example tasks & where to implement them

- Add a new list column mapping for RQS: update `saveRQSData` in `src/services/RqsFormService.ts` and update corresponding web part prop/state types in `src/webparts/*/components`.
- Migrate to SPFI in services: initialize `_sp` in `BaseFormService` and replace `sp.web...` calls with `this._sp.web...`.

## Files to reference while coding

- `src/services/BaseFormService.ts` — base service logic and HRODS helpers
- `src/services/RqsFormService.ts` — saveRQSData example mapping to SharePoint
- `src/services/RqtFormService.ts` — saveRqtData and team validation stub
- `src/common/Constants.ts` — picklist values and options used by UI
- `package.json`, `tsconfig.json`, `README.md` — build and environment rules

If anything is missing or unclear, tell me which area (build, services, data mapping, or SPFX/PnP usage) you want expanded and I will iterate.
