import { ISvstQuestionnaireProps } from "../webparts/svstQuestionnaire/components/ISvstQuestionnaireProps";
import { ISvstQuestionnaireState } from "../webparts/svstQuestionnaire/components/SvstQuestionnaireState";
export default interface IRqsFormService {
    validateHrodsUser(UserId: string, Ctx: ISvstQuestionnaireProps): Promise<boolean>;
    saveRQSData(Rqs_List: string, Data: ISvstQuestionnaireState): Promise<boolean>;
}
//# sourceMappingURL=IRqsFormService.d.ts.map