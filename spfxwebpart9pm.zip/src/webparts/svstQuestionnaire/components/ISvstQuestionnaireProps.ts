import { IExtendedContext } from '../../../common/IExtendedContext';
import IRqsFormService from '../../../services/IRqsFormService';

// Align props with the ReqSpoSite prop conventions (PascalCase)
export interface ISvstQuestionnaireProps {
  SpContext: IExtendedContext;
  FormService: IRqsFormService;
  SiteUrl: string;
  List: string;
  HrodsSpList: string;
  HrodsField: string;
  HrodsDocLib: string;
  HrodsFile: string;
  Description: string;
  IsDarkTheme: boolean;
  EnvironmentMessage: string;
  HasTeamsContext: boolean;
  UserDisplayName: string;
}
