export interface IFileItem {
  id: string;
  title: string;
  extension: string;
  url: string;
  termGuid: string[];
  taxValue: string[];
}