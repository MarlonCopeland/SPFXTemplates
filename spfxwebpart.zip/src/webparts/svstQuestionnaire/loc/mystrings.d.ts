declare interface ISvstQuestionnaireWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  AppLocalEnvironmentSharePoint: string;
  AppLocalEnvironmentTeams: string;
  AppLocalEnvironmentOffice: string;
  AppLocalEnvironmentOutlook: string;
  AppSharePointEnvironment: string;
  AppTeamsTabEnvironment: string;
  AppOfficeEnvironment: string;
  AppOutlookEnvironment: string;
  UnknownEnvironment: string;
  ReqSpoSite:string;
  ReqList:string;
  HrodsList:string;
  HrodsField:string;
  HrodsDoclib:string;
  HrodsFile:string;
}

declare module 'SvstQuestionnaireWebPartStrings' {
  const strings: ISvstQuestionnaireWebPartStrings;
  export = strings;
}
