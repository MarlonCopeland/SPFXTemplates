/// Miscellaneous utility functions

export function isNonNull(str: string | null | undefined): boolean {
    return str !== null && str !== undefined && str.toString().trim().length > 0;
}