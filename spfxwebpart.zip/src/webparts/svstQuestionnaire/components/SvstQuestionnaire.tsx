import * as React from 'react';
import * as $ from 'jquery';
import styles from './SvstQuestionnaire.module.scss';
import { ISvstQuestionnaireProps } from './ISvstQuestionnaireProps';
import { ISvstQuestionnaireState, SvstQuestionnaireStateDefault } from './SvstQuestionnaireState';
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { TaxonomyPicker, IPickerTerms } from "@pnp/spfx-controls-react/lib/TaxonomyPicker";
import * as constants from '../../../common/Constants';
import * as util from '../../../common/Util';


export default class ReqSpoSite extends React.Component<ISvstQuestionnaireProps, ISvstQuestionnaireState> 
{
  
  constructor(props: ISvstQuestionnaireProps) {
    super(props);
    this.state = SvstQuestionnaireStateDefault;
  }

  public componentDidMount(): void {
    if (this.state.rqs_Requestor == null){
      this.setState({rqs_Requestor: this.props.spctx.pageContext.user.displayName});
    } 
    if (this.state.rqs_ParentURL == null){
      this.setState({rqs_ParentURL: this.props.spctx.pageContext.web.absoluteUrl});
    } 
  }

  /// Process form submission
  private handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    this.props.formsvc.saveRQSData(this.props.rqs_list, this.state);
  }

  // Submit enabled flag
  private chkSubmit() : boolean {
    let rstat:boolean = false;
    rstat = (this.state.rqs_SiteTitle !== null) &&
      (this.state.rqs_Manager_ok == true)
      ;

    return rstat;
  }

  private onOrgPickerChange = (terms : IPickerTerms) : void => {
    console.log('onOrgPickerChange : ${terms}');
    if(terms.length>0){
       this.setState({rqs_OwningOrg:terms[0]}, ()=>{this.chkSubmit;});
    } else {
       this.setState({rqs_OwningOrg:null}, ()=>{this.chkSubmit;});
    }
  }
 
  private onSCAPickerChange = async (items: any[],fld:string) : Promise<void> => {
    let o = {};
    if (items.length > 0) {
      if (!items[0].secondaryText){
        console.log(`internal error: unable to extract email from userid <${items[0].loginName}>`);
      }
      o[fld]=items;
      this.setState(o, ()=>{this.chkSubmit;});
    }
    else {
      o[fld] = null;
      this.setState(o, ()=>{this.chkSubmit;});
    }   
  }

  private onManagerPickerChange = async (items: any[]) : Promise<void> => {
    let mv : boolean = false;
    if (items.length > 0) {
      let msg = "";
      for(let i=items.length-1; i>=0; i--){
        if (items[i].secondaryText !== null){
          const v = await this.props.formsvc.validateHrodsUser(items[i].secondaryText, this.props);
          mv = mv||v;
          msg += v ? "" : `<${items[i].text}> is not a HRODS member`;
        }
        else {
          console.log(`internal error: unable to extract email from userid <${items[i].loginName}>`);
        }
      }
      console.log(msg);
      this.setState({rqs_SiteOwners:items,rqs_Manager:items,rqs_Manager_ok:mv,errmsg:msg});  //BUGUKO : artificially accumulating to site owners as well
    }
    else {
      this.setState({rqs_Manager:null,rqs_Manager_ok:mv,errmsg:"select a person"});
    }   
  }

  private onSelectChange = (e : React.ChangeEvent<HTMLSelectElement>) : void => {
    console.log("select changed",e.target.value);
    if (e.target.id in this.state)
    {
       let o = {};
       o[e.target.id] = $('#'+e.target.id+' option:selected').toArray().map((i:HTMLSelectElement) => {
          return i.value!="" ? "\""+i.value+"\"" : "";
       }).join(" ");
       this.setState( o, ()=>{this.chkSubmit;} );
    }
    else
    {
       console.log("error: unknown property ",e.target.id);
    }
  }

  private onCheckboxChange = (e : React.ChangeEvent<HTMLInputElement>) : void => {
    console.log("checkbox changed",e.target.value);
    if (e.target.id in this.state)
    {
       let o = {};
       o[e.target.id] = e.target.checked;
       this.setState( o, ()=>{this.chkSubmit;} );
    }
    else
    {
       console.log("error: unknown property ",e.target.id);
    }
  }

  private onTextChange(e : React.ChangeEvent<HTMLInputElement>) : void {
    console.log("text changed",e.target.value);
    if (e.target.id in this.state)
    {
       let o = {};
       o[e.target.id] = e.target.value;
       this.setState( o, ()=>{this.chkSubmit;} );
    }
    else
    {
       console.log("error: unknown property ",e.target.id);
    }
  }

  private onTAreaChange(e : React.ChangeEvent<HTMLTextAreaElement>) : void {
    console.log("text changed",e.target.value);
    if (e.target.id in this.state)
    {
       let o = {};
       o[e.target.id] = e.target.value;
       this.setState( o, ()=>{this.chkSubmit;} );
    }
    else
    {
       console.log("error: unknown property ",e.target.id);
    }
  }

  private getSitetypeOptions(stypes:Array<string>) : JSX.Element {
    let opts:any = [];
    stypes.map((v)=>{opts.push(<option value={v}>{v}</option>);});
    return opts;
  }

  private getTimeZoneOptions(tzones:Array<string>) : JSX.Element {
    let opts:any = [];
    tzones.map((v)=>{opts.push(<option value={v}>{v}</option>);});
    return opts;
  }

  public render(): React.ReactElement<ISvstQuestionnaireProps> {

    return (
      <div className={styles['ReqSpoSite']}>
        <div className={ styles.title }>New SharePointOnline Site Request</div>
        <form onSubmit={this.handleSubmit}>

            <div className={styles['info']}>
              <div className={styles['name']}>Site Title</div>
              <div className={styles['help']}>unique string that should only have alphanumeric characters</div>
            </div>
            <div className={styles['data']}>
              <div className={styles['entry']}>
                <input className={styles['itext']} aria-label='title' type="text" id="rqs_SiteTitle" onChange={(e:React.ChangeEvent<HTMLInputElement>) => {this.onTextChange(e);}}></input>
              </div>
              <div className={styles['msg']}>additional data related information</div>
            </div>

            <div className={styles['info']}>
              <div className={styles['name']}>Default Time Zone</div>
              <div className={styles['help']}>Select the default timezone of the site</div>
            </div>
            <div className={styles['data']}>
              <div className={styles['entry']}>
                <select aria-label='sitetype' multiple={false} id="rqs_TimeZone" className={styles['iselect']} onChange={(e:React.ChangeEvent<HTMLSelectElement>) => {this.onSelectChange(e);}}>
                  {this.getTimeZoneOptions(constants.TIMEZONES)}
                </select>
              </div>
              <div className={styles['msg']}></div>
            </div>
            
            <div className={styles['info']}>
              <div className={styles['name']}>Site Requestor</div>
              <div className={styles['help']}>Site requestors receive contribute access by default. If you are also the administrator, please enter your name in either the Primary or Secondary Site Collection Administrator field.</div>
            </div>
            <div className={styles['data']}>
              <div className={styles['entry']}>
                <div>{this.state.rqs_Requestor}</div>
              </div>
              <div className={styles['msg']}>current user</div>
            </div>

            <div className={styles['info']}>
              <div className={styles['name']}>Are you a manager?</div>
              <div className={styles['help']}>
                Please check the box if you are a manager. If you are not a manager, leave this box unchecked and enter your manager’s name in the box below.
              </div>
            </div>
            <div className={styles['data']}>
              <div className={styles['entry']}>
                <input aria-label='manager' type="checkbox" id="rqs_IsManager" onChange={(e:React.ChangeEvent<HTMLInputElement>) => {this.onCheckboxChange(e);}}></input>
              </div>
              <div className={styles['msg']}>Check this box if are a manager</div>
            </div>

            <div className={styles['info']}>
              <div className={styles['name']}>Manager</div>
              <div className={styles['help']}>
                If you are not a manager, please enter your manager’s name in the box below. They will be contacted for approval and will be accountable for the security and content of the site.
                Note that an alternative manager may be temporarily entered if your direct manager is out of the office.  After the site is created, the manager's name can be updated via the Site Details link on your new site. 
                Both managers will be notified when a change is submitted.
              </div>
            </div>
            <div className={styles['data']} id="rqs_Manager">
              <div className={styles['entry']}>
                <PeoplePicker
                  context={this.props.spctx}
                  titleText="HRODS Manager Picker"
                  personSelectionLimit={1}
                  showtooltip={true}
                  required={true}
                  disabled={false}
                  ensureUser={true}                  
                  principalTypes={[PrincipalType.User]}
                  onChange={this.onManagerPickerChange}
                  errorMessage={this.state.errmsg}
                  resolveDelay={1000} />
              </div>
              <div className={styles['msg']}>Enter at least 3 characters of the email address for a list of suggestions</div>
            </div>

            <div className={styles['info']}>
              <div className={styles['name']}>PII or FTI</div>
              <div className={styles['help']}>
              If your site will contain Personally Identifiable Information (PII) or Federal Tax Information (FTI), please check this box.
              </div>
            </div>
            <div className={styles['data']}>
              <div className={styles['entry']}>
                <input aria-label='PII' type="checkbox" id="rqs_PII" onChange={(e:React.ChangeEvent<HTMLInputElement>) => {this.onCheckboxChange(e);}}></input>
              </div>
              <div className={styles['msg']}>Check this box if site to contain PII or FTI</div>
            </div>

            <div className={styles['info']}>
              <div className={styles['name']}>FIPS Level</div>
              <div className={styles['help']}>
              Information rated as ‘High’ FIPS security level is not permitted on SharePoint.  For a detailed description of FIPS security standards at SSA, please see the <a href="#" data-bind="click: showFipsTooltipModal" target="_blank">Security Compliance Policy</a>.
              </div>
            </div>
            <div className={styles['data']}>
              <div className={styles['entry']}>
                <select aria-label='FIPS' multiple={false} id="rqs_FIPS" className={styles['iselect']} onChange={(e:React.ChangeEvent<HTMLSelectElement>) => {this.onSelectChange(e);}}>
                  {this.getSitetypeOptions(constants.FIPSLVLS)}
                </select>
              </div>
              <div className={styles['msg']}>Specify site's FIPS level</div>
            </div>

            <div className={styles['info']}>
              <div className={styles['name']}>Site Types</div>
              <div className={styles['help']}>descriptive text regarding site types</div>
            </div>
            <div className={styles['data']}>
              <div className={styles['entry']}>
                <select aria-label='sitetype' multiple={false} id="rqs_SiteType" className={styles['iselect']} onChange={(e:React.ChangeEvent<HTMLSelectElement>) => {this.onSelectChange(e);}}>
                  {this.getSitetypeOptions(constants.SITETYPES)}
                </select>
              </div>
              <div className={styles['msg']}>select a site type.</div>
            </div>

            <div className={styles['info']}>
              <div className={styles['name']}>Owning Organization</div>
              <div className={styles['help']}>
                To select the Owning Organization of your new site, start typing the organization acronym or select the organization by clicking the tags on the right. 
                Once you click the tags, you can expand SSA to drill down to your organization.
                Unable to find your Organization? Click <a href="#" aria-haspopup="true" tabIndex={0} aria-label="request organization" title="Request Organization">here</a> to 
                request that it be added. The request form will open in a separate tab within your current browser.
              </div>
            </div>
            <div className={styles['data']}>
              <div className={styles['entry']} id='rqs_OwningOrg'>
                <TaxonomyPicker
                  allowMultipleSelections={false} 
                  termsetNameOrID="Organizational Hierarchy" 
                  panelTitle="Select Organization"
                  label=""
                  context={this.props.spctx} 
                  onChange={this.onOrgPickerChange} 
                  isTermSetSelectable={false} />
              </div>
              <div className={styles['msg']}>additional data related information</div>
            </div>

            <div className={styles['info']}>
              <div className={styles['name']}>Primary SCA</div>
              <div className={styles['help']}>
                The primary Site Collection Administrator (SCA) is responsible for the site's content and administration.
              </div>
            </div>
            <div className={styles['data']} id="rqs_PrimarySCA">
              <div className={styles['entry']}>
                <PeoplePicker
                  context={this.props.spctx}
                  titleText="SCA Picker"
                  personSelectionLimit={1}
                  showtooltip={true}
                  required={true}
                  disabled={false}
                  ensureUser={true}                  
                  principalTypes={[PrincipalType.User]}
                  onChange={(e)=>this.onSCAPickerChange(e,'rqs_PrimarySCA')}
                  errorMessage={this.state.errmsg}
                  resolveDelay={1000} />
              </div>
              <div className={styles['msg']}>Enter at least 3 characters of the email address for a list of suggestions</div>
            </div>

            <div className={styles['info']}>
              <div className={styles['name']}>Secondary SCA</div>
              <div className={styles['help']}>
                The secondary Site Collection Administrator (SCA) resumes all responsibilities of the primary SCA, in case the primary SCA is not immediately available.
              </div>
            </div>
            <div className={styles['data']} id="rqs_SecondarySCA">
              <div className={styles['entry']}>
                <PeoplePicker
                  context={this.props.spctx}
                  titleText="SCA Picker"
                  personSelectionLimit={1}
                  showtooltip={true}
                  required={true}
                  disabled={false}
                  ensureUser={true}
                  principalTypes={[PrincipalType.User]}
                  onChange={(e)=>this.onSCAPickerChange(e,'rqs_SecondarySCA')}
                  errorMessage={this.state.errmsg}
                  resolveDelay={1000} />
              </div>
              <div className={styles['msg']}>Enter at least 3 characters of the email address for a list of suggestions</div>
            </div>

            <div className={styles['info']}>
              <div className={styles['name']}>Site Description</div>
              <div className={styles['help']}>Briefly describe the site's purpose and content</div>
            </div>
            <div className={styles['data']}>
              <div className={styles['entry']}>
                <textarea aria-label='description' id="rqs_SiteDescription" rows={6} className={styles['inote']} onChange={(e:React.ChangeEvent<HTMLTextAreaElement>) => {this.onTAreaChange(e);}}></textarea>
              </div>
              <div className={styles['msg']}>additional data related information</div>
            </div>

            <div className={styles['actionsDiv']}>
              <div className={styles['actions']}>
                <button type="submit" disabled={!this.chkSubmit()}>Submit</button>
                <button >Cancel</button>
              </div>
            </div>
        </form>
      </div>
    );

  }
}

