import { WebPartContext } from '@microsoft/sp-webpart-base';
import { IReqSpoSiteProps } from "../webparts/ReqSpoSite/components/IReqSpoSiteProps";
import { IReqSpoSiteState } from "../webparts/ReqSpoSite/components/IReqSpoSiteState";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/files";
import '@pnp/sp/site-users/web';
import { BaseFormService } from "./BaseFormService";
import { HrodsProps } from "./IBaseFormService";
import IRqsFormService from "./IRqsFormService";
export declare class RqsFormService extends BaseFormService implements IRqsFormService {
    constructor(SPX: WebPartContext);
    validateHrodsUser(UserId: string, Ctx: IReqSpoSiteProps): Promise<boolean>;
    validateHrodsUsr(UserId: string, Ctx: HrodsProps): Promise<boolean>;
    saveRQSData(Rqs_List: string, Data: IReqSpoSiteState): Promise<boolean>;
}
//# sourceMappingURL=RqsFormService.d.ts.map