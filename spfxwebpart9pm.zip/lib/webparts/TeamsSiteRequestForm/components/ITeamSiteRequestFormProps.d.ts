import { IExtendedContext } from '../../../common/IExtendedContext';
import IRqtFormService from '../../../services/IRqtFormService';
export interface ITeamSiteRequestFormProps {
    SpContext: IExtendedContext;
    FormService: IRqtFormService;
    SiteUrl: string;
    List: string;
    HrodsSpList: string;
    HrodsField: string;
    HrodsDocLib: string;
    HrodsFile: string;
    Description: string;
    IsDarkTheme: boolean;
    EnvironmentMessage: string;
    HasTeamsContext: boolean;
    UserDisplayName: string;
}
//# sourceMappingURL=ITeamSiteRequestFormProps.d.ts.map