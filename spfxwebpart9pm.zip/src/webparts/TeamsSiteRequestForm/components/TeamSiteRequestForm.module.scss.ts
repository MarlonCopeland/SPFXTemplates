
require("./TeamSiteRequestForm.module.css");
const styles = {
  ReqTeam: 'ReqTeam_a0c09c80',
  title: 'title_a0c09c80',
  subTitle: 'subTitle_a0c09c80',
  description: 'description_a0c09c80',
  button: 'button_a0c09c80',
  label: 'label_a0c09c80',
  info: 'info_a0c09c80',
  name: 'name_a0c09c80',
  help: 'help_a0c09c80',
  data: 'data_a0c09c80',
  entry: 'entry_a0c09c80',
  itext: 'itext_a0c09c80',
  iselect: 'iselect_a0c09c80',
  inote: 'inote_a0c09c80',
  msg: 'msg_a0c09c80',
  actionsDiv: 'actionsDiv_a0c09c80',
  actions: 'actions_a0c09c80'
};

export default styles;
