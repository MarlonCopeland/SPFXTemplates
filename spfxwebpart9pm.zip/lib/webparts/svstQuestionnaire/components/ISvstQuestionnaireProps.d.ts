import { IExtendedContext } from '../../../common/IExtendedContext';
import IRqsFormService from '../../../services/IRqsFormService';
export interface ISvstQuestionnaireProps {
    SpContext: IExtendedContext;
    FormService: IRqsFormService;
    SiteUrl: string;
    List: string;
    HrodsSpList: string;
    HrodsField: string;
    HrodsDocLib: string;
    HrodsFile: string;
    Description: string;
    IsDarkTheme: boolean;
    EnvironmentMessage: string;
    HasTeamsContext: boolean;
    UserDisplayName: string;
}
//# sourceMappingURL=ISvstQuestionnaireProps.d.ts.map