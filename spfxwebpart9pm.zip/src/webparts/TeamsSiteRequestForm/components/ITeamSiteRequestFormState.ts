import {  IPickerTerm } from "@pnp/spfx-controls-react/lib/TaxonomyPicker";
  
export interface ITeamSiteRequestFormState {
    Requestor: string;
    AsOwner: boolean;
    IsManager: boolean;
    Approver: any;
    IsPII: boolean;
    FIPS: string;
    Owners: any[];       // multivalued users
    OwningOrg: IPickerTerm | null;
    DcLevel: string;
    TeamName: string;
    Privacy: string;
    Project: string;
    Capstone: string;
    Description: string;   

    ErrorMessage: string;
    TeamNameError: string;
}

export const TeamSiteRequestFormStateDefault: ITeamSiteRequestFormState = {
    Requestor: "",
    AsOwner: false,
    IsManager: false,
    Approver: null,
    IsPII: false,
    FIPS: "",
    Owners: [],
    OwningOrg: null,
    DcLevel: "",
    TeamName: "",
    Privacy: "",
    Project: "",
    Capstone: "",
    Description: "",   

    ErrorMessage: "",
    TeamNameError: ""
};