import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IExtendedContext extends WebPartContext {
    absoluteUrl: string;
}
//# sourceMappingURL=IExtendedContext.d.ts.map