
require("./SvstQuestionnaire.module.css");
const styles = {
  ReqSpoSite: 'ReqSpoSite_18417ace',
  title: 'title_18417ace',
  subTitle: 'subTitle_18417ace',
  description: 'description_18417ace',
  button: 'button_18417ace',
  label: 'label_18417ace',
  info: 'info_18417ace',
  name: 'name_18417ace',
  help: 'help_18417ace',
  data: 'data_18417ace',
  entry: 'entry_18417ace',
  itext: 'itext_18417ace',
  iselect: 'iselect_18417ace',
  inote: 'inote_18417ace',
  msg: 'msg_18417ace',
  actionsDiv: 'actionsDiv_18417ace',
  actions: 'actions_18417ace'
};

export default styles;
