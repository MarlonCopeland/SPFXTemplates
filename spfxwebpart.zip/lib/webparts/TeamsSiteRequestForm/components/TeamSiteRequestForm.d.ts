import * as React from 'react';
import { ITeamSiteRequestFormProps } from './ITeamSiteRequestFormProps';
import { IReqTeamState } from './ITeamSiteRequestFormState';
export default class ReqTeam extends React.Component<ITeamSiteRequestFormProps, IReqTeamState> {
    constructor(props: ITeamSiteRequestFormProps);
    componentDidMount(): void;
    private handleSubmit;
    private chkSubmit;
    private onOrgPickerChange;
    private onOwnerPickerChange;
    private onApproverPickerChange;
    private onSelectChange;
    private onCheckboxChange;
    private onTextChange;
    private onTeamNameChange;
    private onTAreaChange;
    private getOptions;
    render(): React.ReactElement<ITeamSiteRequestFormProps>;
}
//# sourceMappingURL=TeamSiteRequestForm.d.ts.map