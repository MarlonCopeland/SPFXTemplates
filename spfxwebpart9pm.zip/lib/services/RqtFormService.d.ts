import { WebPartContext } from '@microsoft/sp-webpart-base';
import { IReqTeamProps } from "../webparts/ReqTeam/components/IReqTeamProps";
import { IReqTeamState } from "../webparts/ReqTeam/components/IReqTeamState";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/files";
import '@pnp/sp/site-users/web';
import { BaseFormService } from "./BaseFormService";
import { HrodsProps } from "./IBaseFormService";
import IRqtFormService from './IRqtFormService';
import { ServiceKey } from '@microsoft/sp-core-library';
export declare class RqtFormService extends BaseFormService implements IRqtFormService {
    constructor(context: WebPartContext);
    validateHrodsUser(userId: string, ctx: IReqTeamProps): Promise<boolean>;
    validateHrodsUsr(UserId: string, Ctx: HrodsProps): Promise<boolean>;
    validateTeamName(Prefix: string, DCLvl: string, TName: string): Promise<string[]>;
    saveRqtData(listName: string, data: IReqTeamState): Promise<boolean>;
}
export declare const RqtFormServiceKey: ServiceKey<IRqtFormService>;
export default RqtFormService;
//# sourceMappingURL=RqtFormService.d.ts.map