/// Describe purpose of Interface and value purposes
export class HrodsProps {
    public RootSite: string;
    public SharePointList: string;
    public FieldName: string;
    public DocumentLibrary: string;
    public FileName: string;
}

export default interface IBaseFormService {
    // validate user against HRODS gold source
    validateHrodsUsr(UserId:string, Ctx:HrodsProps): Promise<boolean>;
}

