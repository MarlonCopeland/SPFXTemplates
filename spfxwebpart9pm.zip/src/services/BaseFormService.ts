import { SPFI, spfi } from "@pnp/sp";
import { SPFx } from "@pnp/sp";
import { WebPartContext } from '@microsoft/sp-webpart-base';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/files";
import '@pnp/sp/site-users/web';
import * as util from '../common/Util';
import IBaseFormService, { HrodsProps } from "./IBaseFormService";

export class BaseFormService implements IBaseFormService {

    protected _sp: SPFI;

    public constructor(context: WebPartContext) {
        this._sp = spfi().using(SPFx(context));
    }

    // validate user against HRODS gold source
    public async validateHrodsUsr (UserId:string, Ctx:HrodsProps): Promise<boolean> {
        try {
            if (Ctx.DocumentLibrary !== null && Ctx.DocumentLibrary !== undefined){
                return await this.validateHrodsList(UserId, Ctx); // file-based lookup previously considered
            } else {
                return await this.validateHrodsList(UserId, Ctx);
            }
        } catch (ex) {
            console.error(`Error validating user ${UserId} :`, ex);
            return false;
        }
    }

    /// File format : All members would have their unique email saved on a single line (at least) in the HRODS file 
    /// UserId assumed to be an email address
   /* private validateHrodsFile = async (UserId: string, Ctx:HrodsProps) : Promise<boolean> => {
        try {

            // Fetch the file content
            const fp = Ctx.hrods_root+'/'+Ctx.hrods_doclib+'/'+Ctx.hrods_file;
            const fb = await this._sp.web.getFileByServerRelativeUrl(fp).getBuffer();
            const dc = new TextDecoder('utf-8');
            const fc = dc.decode(fb);
            const rows = fc.split('\n');

            // search row containing userid
            if (rows.length > 0 ){
                for (let i = rows.length-1; i >= 0; i--) {
                const r = new RegExp(UserId,'i');
                if(r.test(rows[i])) {
                    console.log(`Matched HRODS entry for <${UserId}> at row #${i}`);
                    return true;
                }
                }
                console.error(`Entry <${UserId}> not found in the HROD file`);
                return false;    

            }
            else {
                console.error(`HRODS file at ${fp} empty. Unable to search for ${UserId}`);
                return false;   
            }

        } catch (ex) {
            console.error(`Error validating user ${UserId} :`, ex);
            return false;
        }
    }*/

    private validateHrodsList = async (userId: string, context: HrodsProps): Promise<boolean> => {
        let isValid: boolean = false;
        if (util.isNonNull(userId)) {
            const list = this._sp.web.lists.getByTitle(context.SharePointList);
            const items: any[] = await (list.items.select(context.FieldName) as any).get();
            isValid = items.some((item: any) => (item[context.FieldName] || '').toString().toLowerCase() === userId.toLowerCase());
        }
        return isValid;
    }
   
}