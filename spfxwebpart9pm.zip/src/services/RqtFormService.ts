// SPFI initialized in BaseFormService
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { IReqTeamProps } from "../webparts/ReqTeam/components/IReqTeamProps";
import { IReqTeamState } from "../webparts/ReqTeam/components/IReqTeamState";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/files";
import '@pnp/sp/site-users/web';
// util not used here
import { BaseFormService } from "./BaseFormService";
import { HrodsProps } from "./IBaseFormService";
import IRqtFormService from './IRqtFormService';
import { ServiceKey } from '@microsoft/sp-core-library';


/// SVST form business rules d
export class RqtFormService extends BaseFormService implements IRqtFormService {

  public constructor (context: WebPartContext) {
      super(context);
  }

  public async validateHrodsUser(userId: string, ctx: IReqTeamProps): Promise<boolean> {
    const bc = new HrodsProps();
    bc.RootSite = ctx.SiteUrl;
    bc.SharePointList = ctx.HrodsSpList;
    bc.FieldName = ctx.HrodsField;
    bc.DocumentLibrary = ctx.HrodsDocLib;
    bc.FileName = ctx.HrodsFile;
    return this.validateHrodsUsr(userId, bc);
  }
    
  public async validateHrodsUsr(UserId:string, Ctx:HrodsProps): Promise<boolean> {
    return super.validateHrodsUsr(UserId,Ctx);
  }

  // validate team name
  public async validateTeamName(Prefix:string, DCLvl:string, TName:string): Promise<string[]> {
    return ['first static error','second static error'];
  }

      
  // Persist form data to the SPO request queue
  public async saveRqtData(listName:string, data:IReqTeamState) : Promise<boolean> {
    if (data.Approver !== null) {
      // optionally validate or map approvers (no-op here)
      (data.Approver as any[]).map((a: any) => a.id);
    }

    let ownerResults = null;
    if (data.Owners !== null) {
      const to = (data.Owners as any[]).map((a: any) => a.id);
      ownerResults = { results: to };
    }

    try {
      await this._sp.web.lists.getByTitle(listName).items.add({
        IsManager: data.IsManager,
        Title: data.TeamName,
        PII: data.IsPII,
        FIPS: data.FIPS,
        ManagerId: data.Owners[0].id,
        OwnersId: ownerResults,
        Description: data.Description,
        OwningOrg: { 
          __metadata: { type: "SP.Taxonomy.TaxonomyFieldValue" },
          Label: data.OwningOrg ? data.OwningOrg.name : '',
          TermGuid: data.OwningOrg ? data.OwningOrg.key : '',
          WssId: -1
        },
      });
      console.log('Item added successfully!');

    } catch (ex) {
      console.error('Error adding item: ', ex);
    }
    
    return true;
  }
}

// ServiceKey for Rqt
export const RqtFormServiceKey: ServiceKey<IRqtFormService> = ServiceKey.create<IRqtFormService>('svst:RqtFormService', RqtFormService as any);

export default RqtFormService;